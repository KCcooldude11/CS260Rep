# HTML website

Basic HTML website to serve as the main view of your work in the course.
